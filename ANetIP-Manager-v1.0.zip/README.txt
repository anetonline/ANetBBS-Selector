ANetIP Manager v1.0
====================

ANetIP Manager is a lightbar-style Linux IP management utility
for BBS SysOps and small server operators.

Requirements
------------
- Linux with systemd/journalctl
- UFW
- dialog
- iproute2 (ss)
- bash

Install
-------
sudo apt install dialog ufw
sudo cp ANetIP-Manager-v1.0.sh /usr/local/bin/anet-ipmgr
sudo chmod +x /usr/local/bin/anet-ipmgr

Run
---
anet-ipmgr

Configuration for ANetBBS selector (you can adapt to another setup if you prefer)
-------------
Defaults:
  Service: bbs-selectors.service
  Ports:   23 22 513 1337 1338 1339

Override without editing the script:

  ANETIP_SERVICE=sbbs.service ANETIP_PORTS="23 22 513" anet-ipmgr

Examples:
  Synchronet:
    ANETIP_SERVICE=sbbs.service ANETIP_PORTS="23 22 513" anet-ipmgr

  Mystic:
    ANETIP_SERVICE=mystic.service ANETIP_PORTS="23 22" anet-ipmgr

Features
--------
- Lightbar / arrow-key interface
- Recent public IPs from the systemd journal
- Connection counts
- Kick active TCP sessions
- Ban with UFW rule inserted at position #1
- Unban IPs
- View current UFW rules
- View recent activity for an IP
- Live connection viewer
- Filters common RFC1918/private IPv4 ranges from recent-IP lists

Notes
-----
The recent-IP parser expects journal messages containing an IPv4 address
in a form similar to:

  ('1.2.3.4', 12345) connected

Different BBS software may use a different log format. In that case the
parser may need a small adjustment.

ANetIP Manager
Created for the BBS/SysOp community.
By: StingRay A-Net Online
