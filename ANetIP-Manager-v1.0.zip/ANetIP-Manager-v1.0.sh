#!/usr/bin/env bash
#
# ANetIP Manager
# Lightbar-style IP kick/ban utility for bbs-selectors.service
#
# Requires: bash, journalctl, ss, ufw, dialog
#

set -u

# -------------------- CONFIGURATION --------------------
# Change these defaults to match the BBS/server you are protecting.
#
# LOG_SERVICE:
#   systemd service whose journal contains connection activity.
#   Example: bbs-selectors.service, sbbs.service, mystic.service
#
# BBS_PORTS:
#   Space-separated TCP ports you want shown in Live Connections.
#
# FIREWALL:
#   Currently supports UFW.
#
LOG_SERVICE="${ANETIP_SERVICE:-bbs-selectors.service}"
BBS_PORTS="${ANETIP_PORTS:-23 22 513 1337 1338 1339}"
FIREWALL="ufw"
TITLE="ANetIP Manager v1.0"
# -------------------------------------------------------
TMPDIR="${TMPDIR:-/tmp}"
WORKDIR="$(mktemp -d "$TMPDIR/anet-ipmgr.XXXXXX")"
trap 'rm -rf "$WORKDIR"' EXIT

require_cmd() {
    command -v "$1" >/dev/null 2>&1 || {
        echo "Missing required command: $1"
        exit 1
    }
}

for cmd in journalctl ss ufw dialog awk grep sort uniq sed sudo; do
    require_cmd "$cmd"
done

if [[ $EUID -ne 0 ]]; then
    exec sudo "$0" "$@"
fi

is_public_ipv4() {
    local ip="$1"
    local a b c d
    IFS=. read -r a b c d <<< "$ip"

    [[ "$a" =~ ^[0-9]+$ && "$b" =~ ^[0-9]+$ && "$c" =~ ^[0-9]+$ && "$d" =~ ^[0-9]+$ ]] || return 1
    (( a <= 255 && b <= 255 && c <= 255 && d <= 255 )) || return 1

    # RFC1918 / loopback / link-local / CGNAT / multicast-reserved
    (( a == 10 )) && return 1
    (( a == 127 )) && return 1
    (( a == 169 && b == 254 )) && return 1
    (( a == 172 && b >= 16 && b <= 31 )) && return 1
    (( a == 192 && b == 168 )) && return 1
    (( a == 100 && b >= 64 && b <= 127 )) && return 1
    (( a >= 224 )) && return 1
    (( a == 0 )) && return 1

    return 0
}

get_recent_ips() {
    local since="${1:-today}"
    local raw="$WORKDIR/raw.log"
    local counts="$WORKDIR/allcounts.txt"
    local out="$WORKDIR/recent.txt"

    journalctl -u "$LOG_SERVICE" --since "$since" --no-pager 2>/dev/null > "$raw"

    # Extract only actual "... ('IP', port) connected" events.
    # Keep the menu bounded so internet scanner traffic cannot create
    # an enormous dialog command line / blank-looking screen.
    awk '
        /\[[a-z]+\] \('\''[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+'\'', [0-9]+\) connected$/ {
            line=$0
            sub(/^.*\('\''/, "", line)
            sub(/'\'',.*$/, "", line)
            print line
        }
    ' "$raw" \
        | sort \
        | uniq -c \
        | sort -nr > "$counts"

    : > "$out"

    while read -r count ip; do
        [[ -z "${ip:-}" ]] && continue

        if is_public_ipv4 "$ip"; then
            printf "%s %s\n" "$count" "$ip" >> "$out"
        fi
    done < "$counts"

    # Top 100 public IPs is plenty for an interactive lightbar.
    head -n 100 "$out"
}

is_banned() {
    local ip="$1"
    ufw status 2>/dev/null | grep -Fq "$ip"
}

kick_ip() {
    local ip="$1"
    ss -K src "$ip" >/dev/null 2>&1 || true
    ss -K dst "$ip" >/dev/null 2>&1 || true
}

ban_ip() {
    local ip="$1"
    if is_banned "$ip"; then
        dialog --title "$TITLE" --msgbox "$ip is already present in UFW rules." 7 55
        return
    fi

    ufw insert 1 deny from "$ip" >/dev/null 2>&1
    kick_ip "$ip"

    dialog --title "$TITLE" --msgbox \
        "$ip has been BANNED at the TOP of UFW and any current TCP sessions were kicked." 9 68
}

unban_ip() {
    local ip="$1"
    if ! is_banned "$ip"; then
        dialog --title "$TITLE" --msgbox "$ip does not appear in the current UFW rules." 7 58
        return
    fi

    # Delete all matching simple "deny from IP" rules.
    # Re-run until no exact matching rule remains.
    while ufw status numbered 2>/dev/null | grep -F "$ip" >/dev/null; do
        local num
        num="$(ufw status numbered 2>/dev/null \
            | grep -F "$ip" \
            | head -n1 \
            | sed -n 's/^\[[[:space:]]*\([0-9]\+\)\].*/\1/p')"
        [[ -z "$num" ]] && break
        yes | ufw delete "$num" >/dev/null 2>&1
    done

    dialog --title "$TITLE" --msgbox "$ip has been removed from the UFW rules." 7 55
}

show_ip_activity() {
    local ip="$1"
    journalctl -u "$LOG_SERVICE" --since today --no-pager 2>/dev/null \
        | grep -F "$ip" \
        | tail -n 100 > "$WORKDIR/activity.txt"

    if [[ ! -s "$WORKDIR/activity.txt" ]]; then
        echo "No service activity found today for $ip." > "$WORKDIR/activity.txt"
    fi

    dialog --title "Activity: $ip" --textbox "$WORKDIR/activity.txt" 24 100
}

ip_action_menu() {
    local ip="$1"
    local choice

    while true; do
        local banned="NO"
        is_banned "$ip" && banned="YES"

        choice="$(dialog --clear \
            --title "$TITLE" \
            --menu "Selected: $ip    Banned: $banned\n\nChoose an action:" \
            18 70 8 \
            1 "Kick current connection(s)" \
            2 "BAN IP + kick immediately" \
            3 "Unban IP" \
            4 "View today's service activity" \
            5 "Back" \
            3>&1 1>&2 2>&3)" || return

        case "$choice" in
            1)
                kick_ip "$ip"
                dialog --title "$TITLE" --msgbox \
                    "Kill commands sent for all TCP sessions involving $ip." 7 60
                ;;
            2)
                if dialog --title "CONFIRM BAN" \
                    --yesno "Ban $ip from this server and kick current sessions?" 8 60; then
                    ban_ip "$ip"
                fi
                ;;
            3)
                if dialog --title "CONFIRM UNBAN" \
                    --yesno "Remove $ip from UFW rules?" 8 55; then
                    unban_ip "$ip"
                fi
                ;;
            4)
                show_ip_activity "$ip"
                ;;
            5)
                return
                ;;
        esac
    done
}

recent_ip_menu() {
    local since="$1"
    local label="$2"
    local data="$WORKDIR/menu-data.txt"
    get_recent_ips "$since" > "$data"

    if [[ ! -s "$data" ]]; then
        dialog --title "$TITLE" --msgbox \
            "No public IPv4 connections found for: $label" 7 55
        return
    fi

    local args=()
    while read -r count ip; do
        local mark=""
        is_banned "$ip" && mark=" [BANNED]"
        args+=("$ip" "$count connection(s)$mark")
    done < "$data"

    local selected
    selected="$(dialog --clear \
        --title "$TITLE - $label" \
        --menu "Use Up/Down arrows, Enter to select.\nPrivate/LAN IPs are hidden." \
        24 75 16 \
        "${args[@]}" \
        3>&1 1>&2 2>&3)" || return

    ip_action_menu "$selected"
}

manual_ip() {
    local ip
    ip="$(dialog --title "$TITLE" \
        --inputbox "Enter IPv4 address:" 8 50 \
        3>&1 1>&2 2>&3)" || return

    if [[ ! "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        dialog --title "$TITLE" --msgbox "That does not look like an IPv4 address." 7 52
        return
    fi

    ip_action_menu "$ip"
}

show_bans() {
    ufw status numbered > "$WORKDIR/bans.txt" 2>&1
    dialog --title "Current UFW Rules" --textbox "$WORKDIR/bans.txt" 24 90
}

show_live_connections() {
    local regex=""
    local p

    for p in $BBS_PORTS; do
        [[ -n "$regex" ]] && regex+="|"
        regex+=":${p}\b"
    done

    ss -tnp 2>/dev/null \
        | grep -E "$regex" > "$WORKDIR/live.txt" || true

    if [[ ! -s "$WORKDIR/live.txt" ]]; then
        echo "No active TCP connections currently shown on configured BBS ports: $BBS_PORTS" \
            > "$WORKDIR/live.txt"
    fi

    dialog --title "Live BBS Connections" --textbox "$WORKDIR/live.txt" 20 110
}

check_ufw() {
    if ! ufw status 2>/dev/null | grep -q "^Status: active"; then
        dialog --title "$TITLE" --msgbox \
            "WARNING: UFW does not appear to be active.\n\nBan/unban actions require active UFW." 9 62
    fi
}


show_about() {
    cat > "$WORKDIR/about.txt" <<EOF
ANetIP Manager v1.0

A generic lightbar-style IP management utility for Linux BBS / server SysOps.

Current configuration:
  Journal service : $LOG_SERVICE
  BBS TCP ports   : $BBS_PORTS
  Firewall        : $FIREWALL

Environment overrides:
  ANETIP_SERVICE="your-service.service"
  ANETIP_PORTS="23 22 513"

Example:
  ANETIP_SERVICE=sbbs.service ANETIP_PORTS="23 22 513" anet-ipmgr

Features:
  - Recent public IPs from systemd journal
  - Connection counts
  - Kick active TCP sessions
  - Ban IPs at UFW rule #1
  - Unban IPs
  - View current UFW rules
  - Hide common private/LAN IPv4 ranges from recent-IP lists

IMPORTANT:
  This tool assumes your journal lines contain IPv4 addresses in a form
  similar to ('1.2.3.4', 12345) connected.

  UFW must be active for ban/unban functions.
EOF
    dialog --title "About / Configuration" --textbox "$WORKDIR/about.txt" 24 82
}

main_menu() {
    check_ufw

    while true; do
        local choice
        choice="$(dialog --clear \
            --title "$TITLE" \
            --menu "Arrow keys move the lightbar. Press Enter to select.\nService: $LOG_SERVICE" \
            23 76 12 \
            1 "Recent public IPs - today" \
            2 "Recent public IPs - last 24 hours" \
            3 "Recent public IPs - last 7 days" \
            4 "Live BBS connections" \
            5 "Enter an IP manually" \
            6 "View current UFW rules / bans" \
            7 "About / configuration" \
            8 "Exit" \
            3>&1 1>&2 2>&3)" || break

        case "$choice" in
            1) recent_ip_menu "today" "Today" ;;
            2) recent_ip_menu "24 hours ago" "Last 24 Hours" ;;
            3) recent_ip_menu "7 days ago" "Last 7 Days" ;;
            4) show_live_connections ;;
            5) manual_ip ;;
            6) show_bans ;;
            7) show_about ;;
            8) break ;;
        esac
    done

    clear
}

main_menu
